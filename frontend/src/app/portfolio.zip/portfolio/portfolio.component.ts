import { Component, OnInit } from '@angular/core';
import {UserService} from "../services/user.service";
import {Portfolio, PortfolioElement, User} from "../../models";
import {PortfolioService} from "../services/portfolio.service";

@Component({
  selector: 'app-portfolio',
  templateUrl: './portfolio.component.html',
  styleUrls: ['./portfolio.component.css']
})
export class PortfolioComponent implements OnInit {
  user: User | undefined;

  elements: PortfolioElement[] = [];

  investments: String = '0';

  constructor(
    private userService: UserService,
    private portfolioService: PortfolioService
  ) { }

  ngOnInit(): void {
    this.getUser();
    this.getPortfolio();
  }

  getUser(){
    return this.userService.getUser().subscribe((data) => {
      console.log(data)
      this.user = data;
    });
  }

  getPortfolio(){
    this.portfolioService.getPortfolioElements().subscribe((data) => {
      this.elements = data;
      this.calculateInvestments();
    });
  }

  calculateInvestments(){
    let sum = 0;

    if (this.user) {
      for (let curr of this.elements) {
        sum = sum + (+curr.quantity * +curr.CoinDetails.quote.USD.price);
      }
    }
    this.investments = sum.toFixed(2);
  }

}
